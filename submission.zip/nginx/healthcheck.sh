#!/bin/bash

curl -f https://localhost:8443 -k || exit 1
