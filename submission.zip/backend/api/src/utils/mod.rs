//! Useful utilities used across the application in miscellaneous places.
pub mod email;
pub mod httperror;
