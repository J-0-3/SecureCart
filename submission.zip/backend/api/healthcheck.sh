#!/bin/sh

curl -f http://localhost || exit 1
