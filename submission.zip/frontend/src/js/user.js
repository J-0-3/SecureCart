"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var is_admin = false;
var target_user_id = null;
var viewing_self = false;
document.addEventListener("DOMContentLoaded", init_user_page);
function init_user_page() {
    return __awaiter(this, void 0, void 0, function () {
        var res, err_1, url_params, query_user_id, user_url, res, user, err_2;
        var _this = this;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4, fetch("/api/auth/check/admin")];
                case 1:
                    res = _a.sent();
                    is_admin = res.ok;
                    return [3, 3];
                case 2:
                    err_1 = _a.sent();
                    console.error("Admin check error:", err_1);
                    is_admin = false;
                    return [3, 3];
                case 3:
                    url_params = new URLSearchParams(window.location.search);
                    query_user_id = url_params.get("user_id");
                    if (is_admin && query_user_id) {
                        target_user_id = query_user_id;
                    }
                    else {
                        target_user_id = null;
                    }
                    viewing_self = target_user_id === null;
                    if (!is_admin || viewing_self) {
                        document.getElementById("password_section").style.display = "block";
                        document.getElementById("2fa_section").style.display = "block";
                    }
                    user_url = target_user_id
                        ? "/api/users/".concat(target_user_id)
                        : "/api/users/self";
                    _a.label = 4;
                case 4:
                    _a.trys.push([4, 7, , 8]);
                    return [4, fetch_csrf(user_url)];
                case 5:
                    res = _a.sent();
                    if (!res.ok)
                        throw new Error("Failed to fetch user data");
                    return [4, res.json()];
                case 6:
                    user = _a.sent();
                    populate_form(user);
                    return [3, 8];
                case 7:
                    err_2 = _a.sent();
                    console.error(err_2);
                    show_user_page_message_modal("Error fetching user data");
                    return [3, 8];
                case 8:
                    document.getElementById("user_form").addEventListener("submit", update_user);
                    document
                        .getElementById("delete_user")
                        .addEventListener("click", delete_user);
                    document
                        .getElementById("promote_user")
                        .addEventListener("click", promote_user);
                    document.getElementById("2fa-button").addEventListener("click", function () { return __awaiter(_this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            window.location.replace("/enroll2fa.html");
                            return [2];
                        });
                    }); });
                    return [2];
            }
        });
    });
}
function populate_form(user) {
    document.getElementById("email").value = user.email;
    document.getElementById("forename").value =
        user.forename;
    document.getElementById("surname").value = user.surname;
    document.getElementById("address").value =
        user.address;
    document.getElementById("role_display").textContent =
        user.role;
    if (is_admin && target_user_id && user.role === "Customer") {
        document.getElementById("promote_user").style.display = "block";
    }
    if (user.role.toLowerCase() === "customer") {
        load_orders();
    }
    else {
        document.getElementById("orders_section").style.display = "none";
    }
}
function update_user(event) {
    return __awaiter(this, void 0, void 0, function () {
        var email, forename, surname, address, user_url, res, err_3, password, res, err_4;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    event.preventDefault();
                    email = document.getElementById("email").value;
                    forename = document.getElementById("forename")
                        .value;
                    surname = document.getElementById("surname")
                        .value;
                    address = document.getElementById("address")
                        .value;
                    user_url = target_user_id
                        ? "/api/users/".concat(target_user_id)
                        : "/api/users/self";
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4, fetch_csrf(user_url, {
                            method: "PUT",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ email: email, forename: forename, surname: surname, address: address }),
                        })];
                case 2:
                    res = _a.sent();
                    if (!res.ok)
                        throw new Error("Failed to update user details");
                    show_user_page_message_modal("User updated successfully");
                    return [3, 4];
                case 3:
                    err_3 = _a.sent();
                    console.error(err_3);
                    show_user_page_message_modal("Error updating user");
                    return [3, 4];
                case 4:
                    if (!viewing_self) return [3, 8];
                    password = document.getElementById("password")
                        .value;
                    if (!(password.trim().length > 0)) return [3, 8];
                    _a.label = 5;
                case 5:
                    _a.trys.push([5, 7, , 8]);
                    return [4, fetch_csrf("/api/users/self/credential", {
                            method: "PUT",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ Password: { password: password } }),
                        })];
                case 6:
                    res = _a.sent();
                    if (!res.ok)
                        throw new Error("Failed to update password");
                    show_user_page_message_modal("Password updated successfully");
                    return [3, 8];
                case 7:
                    err_4 = _a.sent();
                    console.error(err_4);
                    show_user_page_message_modal("Error updating password");
                    return [3, 8];
                case 8: return [2];
            }
        });
    });
}
function delete_user() {
    return __awaiter(this, void 0, void 0, function () {
        var user_url, res, err_5;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!confirm("Are you sure you want to permanently delete this account? This cannot be undone.")) {
                        return [2];
                    }
                    user_url = target_user_id
                        ? "/api/users/".concat(target_user_id)
                        : "/api/users/self";
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4, fetch_csrf(user_url, { method: "DELETE" })];
                case 2:
                    res = _a.sent();
                    if (!res.ok)
                        throw new Error("Failed to delete user");
                    show_user_page_message_modal("User deleted successfully");
                    window.location.replace("/");
                    return [3, 4];
                case 3:
                    err_5 = _a.sent();
                    console.error(err_5);
                    show_user_page_message_modal("Error deleting user");
                    return [3, 4];
                case 4: return [2];
            }
        });
    });
}
function promote_user() {
    return __awaiter(this, void 0, void 0, function () {
        var res, err_6;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!target_user_id)
                        return [2];
                    if (!confirm("Are you sure you want to promote this user to an admin? It will not be possible to demote them afterwards.")) {
                        return [2];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4, fetch_csrf("/api/auth/users/".concat(target_user_id, "/promote"), {
                            method: "POST",
                        })];
                case 2:
                    res = _a.sent();
                    if (!res.ok)
                        throw new Error("Failed to promote user");
                    show_user_page_message_modal("User promoted to admin");
                    setTimeout(function () { return window.location.reload(); }, 1000);
                    return [3, 4];
                case 3:
                    err_6 = _a.sent();
                    console.error(err_6);
                    show_user_page_message_modal("Error promoting user");
                    return [3, 4];
                case 4: return [2];
            }
        });
    });
}
function show_user_page_message_modal(message) {
    document.getElementById("alert-modal-body").textContent = message;
    var modal = new bootstrap.Modal(document.getElementById("alert-modal"));
    modal.show();
}
function load_orders() {
    return __awaiter(this, void 0, void 0, function () {
        var orders_url, res, order_res, orders, orders_list_1, li, error_1, ordersList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    orders_url = "";
                    if (is_admin && target_user_id) {
                        orders_url = "/api/orders?user_id=".concat(target_user_id);
                    }
                    else {
                        orders_url = "/api/orders";
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4, fetch_csrf(orders_url)];
                case 2:
                    res = _a.sent();
                    if (!res.ok)
                        throw new Error("Failed to fetch orders");
                    return [4, res.json()];
                case 3:
                    order_res = _a.sent();
                    orders = order_res.orders;
                    orders_list_1 = document.getElementById("orders_list");
                    if (!orders_list_1)
                        return [2];
                    orders_list_1.innerHTML = "";
                    if (orders.length === 0) {
                        li = document.createElement("li");
                        li.className = "list-group-item";
                        li.textContent = "No orders found.";
                        orders_list_1.appendChild(li);
                        return [2];
                    }
                    orders.forEach(function (order) {
                        var li = document.createElement("li");
                        li.className = "list-group-item list-group-item-action";
                        var pounds = (order.amount_charged / 100).toFixed(2);
                        li.innerHTML = "<strong>Order ID:</strong> ".concat(order.id, " \u2013 <strong>Amount:</strong> \u00A3").concat(pounds, " \u2013 <strong>Placed:</strong> ").concat(new Date(order.order_placed).toLocaleString(), " \u2013 <strong>Status:</strong> ").concat(order.status);
                        li.style.cursor = "pointer";
                        li.addEventListener("click", function () {
                            window.location.replace("/order.html?order=".concat(order.id));
                        });
                        orders_list_1.appendChild(li);
                    });
                    return [3, 5];
                case 4:
                    error_1 = _a.sent();
                    console.error("Error loading orders:", error_1);
                    ordersList = document.getElementById("orders_list");
                    if (ordersList) {
                        ordersList.innerHTML =
                            '<li class="list-group-item text-danger">Error loading orders.</li>';
                    }
                    return [3, 5];
                case 5: return [2];
            }
        });
    });
}
