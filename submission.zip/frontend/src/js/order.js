"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
document.addEventListener("DOMContentLoaded", init_order_page);
function init_order_page() {
    return __awaiter(this, void 0, void 0, function () {
        var url_params, order_id, message, auth_res, _1, is_admin, order_data, order_res, err_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    url_params = new URLSearchParams(window.location.search);
                    order_id = url_params.get("order");
                    message = url_params.get("message");
                    if (!order_id) {
                        window.location.replace("/index.html");
                        return [2];
                    }
                    if (message) {
                        show_message_modal(message);
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4, fetch_csrf("/api/auth/check")];
                case 2:
                    auth_res = _a.sent();
                    if (!auth_res.ok) {
                        window.location.replace("/index.html");
                    }
                    return [3, 4];
                case 3:
                    _1 = _a.sent();
                    window.location.replace("/index.html");
                    return [3, 4];
                case 4: return [4, fetch_csrf("/api/auth/check/admin")];
                case 5:
                    is_admin = (_a.sent()).ok;
                    _a.label = 6;
                case 6:
                    _a.trys.push([6, 9, , 10]);
                    return [4, fetch_csrf("/api/orders/".concat(order_id))];
                case 7:
                    order_res = _a.sent();
                    if (!order_res.ok) {
                        if (order_res.status === 401 || order_res.status === 403) {
                            window.location.replace("/index.html");
                            return [2];
                        }
                        else if (order_res.status === 404) {
                            window.location.replace("/error/404.html");
                        }
                        throw new Error("Failed to fetch order data");
                    }
                    return [4, order_res.json()];
                case 8:
                    order_data = _a.sent();
                    return [3, 10];
                case 9:
                    err_1 = _a.sent();
                    console.error("Error fetching order:", err_1);
                    window.location.replace("/index.html");
                    return [2];
                case 10: return [4, render_order(order_data, is_admin)];
                case 11:
                    _a.sent();
                    if (is_admin && order_data.order.status === "Confirmed") {
                        show_fulfil_button(order_id);
                    }
                    return [2];
            }
        });
    });
}
function show_message_modal(message) {
    document.getElementById("alert-modal-body").textContent = message;
    var modal = new bootstrap.Modal(document.getElementById("alert-modal"));
    modal.show();
}
function render_order(order_data, is_admin) {
    return __awaiter(this, void 0, void 0, function () {
        var container, user_info, user_res, _a, err_2, items_list, _i, _b, item, product_url, quantity;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    container = document.getElementById("order_container");
                    if (!container)
                        return [2];
                    user_info = null;
                    _c.label = 1;
                case 1:
                    _c.trys.push([1, 8, , 9]);
                    if (!is_admin) return [3, 3];
                    return [4, fetch_csrf("/api/users/".concat(order_data.order.user_id))];
                case 2:
                    _a = _c.sent();
                    return [3, 5];
                case 3: return [4, fetch_csrf("/api/users/self")];
                case 4:
                    _a = _c.sent();
                    _c.label = 5;
                case 5:
                    user_res = _a;
                    if (!user_res.ok) return [3, 7];
                    return [4, user_res.json()];
                case 6:
                    user_info = _c.sent();
                    _c.label = 7;
                case 7: return [3, 9];
                case 8:
                    err_2 = _c.sent();
                    console.error("Error fetching user info:", err_2);
                    return [3, 9];
                case 9:
                    container.innerHTML = "\n    <h2>Order #".concat(order_data.order.id, "</h2>\n    <p><strong>Status:</strong> ").concat(order_data.order.status, "</p>\n    <p><strong>Order Placed:</strong> ").concat(new Date(order_data.order.order_placed).toLocaleString(), "</p>\n    <p><strong>Amount Charged:</strong> \u00A3").concat((order_data.order.amount_charged / 100).toFixed(2), "</p>\n    <p><strong>User Email:</strong> <span id=\"order-user-email\"></span></p>\n    <p><strong>Shipping Address:</strong> <span id=\"order-user-address\"></span></p>\n    <h3>Items</h3>\n    <ul id=\"order_items_list\" class=\"list-group\"></ul>\n  ");
                    document.getElementById("order-user-email").textContent = user_info
                        ? user_info.email
                        : order_data.order.user_id.toString();
                    document.getElementById("order-user-address").textContent = user_info
                        ? user_info.address
                        : "";
                    items_list = document.getElementById("order_items_list");
                    if (!items_list)
                        return [2];
                    _i = 0, _b = order_data.items;
                    _c.label = 10;
                case 10:
                    if (!(_i < _b.length)) return [3, 13];
                    item = _b[_i];
                    product_url = item[0];
                    quantity = item[1];
                    return [4, fetch_product_and_append(product_url, quantity, items_list)];
                case 11:
                    _c.sent();
                    _c.label = 12;
                case 12:
                    _i++;
                    return [3, 10];
                case 13: return [2];
            }
        });
    });
}
function fetch_product_and_append(uri, quantity, container) {
    return __awaiter(this, void 0, void 0, function () {
        var resp, product, li, err_3, li;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4, fetch_csrf(uri)];
                case 1:
                    resp = _a.sent();
                    if (!resp.ok)
                        throw new Error("Failed to fetch product");
                    return [4, resp.json()];
                case 2:
                    product = _a.sent();
                    li = document.createElement("li");
                    li.className =
                        "list-group-item d-flex justify-content-between align-items-center";
                    li.textContent = "".concat(product.name, " - \u00A3").concat((product.price / 100).toFixed(2), " x ").concat(quantity);
                    container.appendChild(li);
                    return [3, 4];
                case 3:
                    err_3 = _a.sent();
                    console.error("Error fetching product:", uri, err_3);
                    li = document.createElement("li");
                    li.className = "list-group-item";
                    li.textContent = "Failed to load";
                    container.appendChild(li);
                    return [3, 4];
                case 4: return [2];
            }
        });
    });
}
function show_fulfil_button(order_id) {
    var _this = this;
    var fulfil_container = document.getElementById("fulfil_button_container");
    var fulfil_button = document.createElement("button");
    fulfil_button.id = "fulfil_button";
    fulfil_button.className = "btn btn-primary";
    fulfil_button.textContent = "Fulfil Order";
    fulfil_button.addEventListener("click", function () { return __awaiter(_this, void 0, void 0, function () {
        var res, order_res, order_data, err_4;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 5, , 6]);
                    return [4, fetch_csrf("/api/orders/".concat(order_id, "/fulfil"), {
                            method: "POST",
                        })];
                case 1:
                    res = _a.sent();
                    if (!res.ok)
                        throw new Error("Failed to fulfil order");
                    return [4, fetch_csrf("/api/orders/".concat(order_id))];
                case 2:
                    order_res = _a.sent();
                    if (!order_res.ok)
                        throw new Error("Failed to fetch updated order");
                    return [4, order_res.json()];
                case 3:
                    order_data = _a.sent();
                    return [4, render_order(order_data, true)];
                case 4:
                    _a.sent();
                    if (order_data.order.status === "Fulfilled") {
                        fulfil_container.innerHTML = "";
                        show_message_modal("Order fulfilled successfully");
                    }
                    return [3, 6];
                case 5:
                    err_4 = _a.sent();
                    console.error(err_4);
                    show_message_modal("Error fulfilling order: ".concat(err_4));
                    return [3, 6];
                case 6: return [2];
            }
        });
    }); });
    fulfil_container.appendChild(fulfil_button);
}
