#!/bin/bash

curl -f http://localhost || exit 1
